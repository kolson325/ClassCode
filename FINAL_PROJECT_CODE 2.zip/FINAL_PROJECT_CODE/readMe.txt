Installation Instructions:

1. Make sure you have XAMPP installed on your system.
2. Import the database from the ExerciseProjectVersion2.sql file into your MySQL database.
3. Place the 'FINAL_PROJECT_CODE' folder into the 'htdocs' directory of your XAMPP installation.
4. In your web browser, navigate to http://localhost/FINAL_PROJECT_CODE/login.php to access the application.



***YOU MUST REGISTER BEFORE LOGGING IN ****
***SINCE THIS IS THE BETA YOU WILL SELECT YOUR USERTYPE (ADMIN OR USER)***

***Choosing one or the other will send you to different starting pages***
Example User Credentials:
- Admin Account:
  - Username: admin
  - Password: password

- User Account:
  - Username: user
  - Password: password

